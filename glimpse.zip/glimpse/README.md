Glimpse
================

Atomspace Viewer
https://github.com/opencog/atomspace

Setup
--------
```sh
npm install -g bower
bower install
```

Run
---
```sh
./StartServer
```

Goto http://localhost:8000 in your browser.


