library dock_spawn_demo_ide;

import 'dart:html';
import 'package:dock_spawn/dock_spawn.dart';

part 'ide/spawn_ide.dart';
part 'ide/panels/editor_panel.dart';

void main() {
  new SpawnIDE();
}

