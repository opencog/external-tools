part of dock_spawn;

class DockException {
  String message;
  
  DockException(this.message);
  String toString() => message;
}
