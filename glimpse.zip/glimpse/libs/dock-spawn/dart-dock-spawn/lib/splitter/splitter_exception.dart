part of dock_spawn;

class SplitterException {
  String message;
  SplitterException(this.message);
}
