/*
 Contains various helper functions
 */


var isNode = function (atom) {
    return atom["type"].indexOf("Node") > -1;
};

var isLink = function (atom) {
    return atom["type"].indexOf("Link") > -1;
};


var processAtoms = function (atoms) {
    var graph = {nodes: [], links: []};
    var raw_links = [];
    for (var atom_index = 0; atom_index < atoms.length; atom_index++) {
        var atom = atoms[atom_index];
        graph.nodes.push({
            handle: atom["handle"],
            label: atom["name"],
            type: atom["type"]
        });

        if (isLink(atom)) {
            for (var outgoing_index = 0; outgoing_index < atom["outgoing"].length; outgoing_index++) {
                raw_links.push({
                    source: atom["handle"],
                    target: atom["outgoing"][outgoing_index],
                    label: "POWcc",
                    type: atom["type"]
                });
            }
        }
    }

    raw_links.forEach(function (e) {
        var sourceNode = graph.nodes.filter(function (n) {
                return n.handle === e.source;
            })[0],
            targetNode = graph.nodes.filter(function (n) {
                return n.handle === e.target;
            })[0];
        graph.links.push({source: sourceNode, target: targetNode, label: e.label, type: "Link"});
    });

    return graph;
};


var compareNodes = function (node1, node2) {
    return (node1.handle == node2.handle);
};

var compareLinks = function (link1, link2) {
    return (link1.source.handle == link2.source.handle) && (link1.target.handle == link2.target.handle);
};